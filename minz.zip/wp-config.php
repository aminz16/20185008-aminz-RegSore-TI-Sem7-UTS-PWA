<?php
define( 'WP_CACHE', true );
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'kotakuid_wp653' );

/** Database username */
define( 'DB_USER', 'kotakuid_wp653' );

/** Database password */
define( 'DB_PASSWORD', '4.7-S45Wop' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'elhwt3po5qzj48fp2mb3ut6qwfupp1kwgzmtpudonekvneguyehfuoeqdyxu2cx9' );
define( 'SECURE_AUTH_KEY',  'pzgdenn0bfzko0olkjahqxezqr3i0urnaqly2cd1jri0v8jt9esxngm13ttkjbko' );
define( 'LOGGED_IN_KEY',    'sa5uuu19dtc8xkgk3vp7vmswuislr5xjzjzmv8rbgnomkkyjfan3rzcczh9owyyd' );
define( 'NONCE_KEY',        '3k7vtqyojb9hbbmrl8xzsy4zucdxqrn91ekigxt9hliksvfa7vqwedvwn0ms1yer' );
define( 'AUTH_SALT',        'tpmyzu1wijqfx5jzoevx973oiv1sfg0pnuwf5yxkrzangpldwv7zh4ht1ife6d5v' );
define( 'SECURE_AUTH_SALT', 'uabjxojjfwqgouqp7soscouxouf52414w02091mu0jcd9y0uepfzcrc4blhzf6v6' );
define( 'LOGGED_IN_SALT',   '9toudiaa3xvqtzl2t7sdcroirsqorid7qwq0usw8wfn6kpsgzeapsnbqzvhnthup' );
define( 'NONCE_SALT',       'mycdct8ogolbesmoeqdokluwemugmo3wjpdup99rns5fj0rqscjxroivazagvc5x' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpfk_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
